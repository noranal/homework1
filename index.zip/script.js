function validateForm() {
    let firstName = document.getElementById("firstName").value;
    let lastName = document.getElementById("lastName").value;
    let phone = document.getElementById("phone").value;
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;
    let confirmPassword = document.getElementById("confirmPassword").value;

    let isValid = true;

    // ����� ����� ������ �����
    let emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailPattern.test(email)) {
        isValid = false;
        document.getElementById("email").style.borderColor = "red";
    }

    // ����� ���� �����
    if (password.length < 8) {
        isValid = false;
        document.getElementById("password").style.borderColor = "red";
    }

    // ����� ������ �����
    if (password !== confirmPassword) {
        isValid = false;
        document.getElementById("confirmPassword").style.borderColor = "red";
    }

    return isValid;
}
